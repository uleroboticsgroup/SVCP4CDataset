#include <string.h>
#include <stdio.h>
 
int main() {

	char password[] = "gramsec2018";
	char user[] = "riasc";

   	strcpy(user, password);

   	printf("User: %s\n", user);
   	printf("Password: %s\n", password);

	return 0;
}
//						↓↓↓VULNERABLE LINES↓↓↓

// 9,4;9,10

